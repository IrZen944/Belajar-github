<?php
/*
 This is the configuration file for the moz accessID and secretkey for RED HAWK's bloggers view scan.
 If you are not a blogger or in other words if you are not interested in some geeky bloggers info about the target site you can leave this file alone.

 - But I am interested and don't know where to get these keys from :'( ...
 -- Well in that case go and create a account in moz.com and generate your bunch of keys here: https://moz.com/products/mozscape/access

 PLEASE NOTE: free accounts have limitations of 27,000 calls per month which i belive is more then enough but if this falls short for you, just create a new account in moz and get a new bunch of keys and replace your old ones.
*/

$accessID = "put your access id in between the quotes"; // this is where you put your access ID
$secretKey = "paste your secretkey in between the quotes"; // Your secret key goes here

?>
